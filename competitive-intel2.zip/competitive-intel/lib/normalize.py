"""Channel name normalization. The diff engine compares canonical names only.

Reads channel_aliases.yml at import time. To pick up new aliases without restarting,
call reload_aliases()."""

import re
from pathlib import Path
import yaml

_CONFIG_PATH = Path(__file__).parent.parent / "config" / "channel_aliases.yml"
_ALIASES: dict[str, str] = {}


def reload_aliases() -> None:
    """Re-read the aliases config from disk."""
    global _ALIASES
    with open(_CONFIG_PATH) as f:
        data = yaml.safe_load(f)
    _ALIASES = data.get("aliases", {}) if data else {}


def normalize(observed: str) -> str:
    """Convert a scraped channel name into its canonical form.

    Rules applied in order:
      1. Strip whitespace
      2. Apply the alias table (exact match)
      3. Strip common suffixes: " HD", " 4K", trailing "(East)" / "(West)"
      4. Collapse multiple spaces
      5. Title-case is preserved as-given (do not lowercase)

    Returns the canonical name. If no alias and no suffix applies,
    returns the cleaned-up observed name unchanged."""
    if not _ALIASES:
        reload_aliases()

    s = observed.strip()
    if not s:
        return s

    # Exact alias hit wins
    if s in _ALIASES:
        return _ALIASES[s]

    # Strip common suffixes
    cleaned = s
    cleaned = re.sub(r"\s+(HD|4K|UHD)$", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s+\((East|West|Pacific|Central)\)$", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s+(East|West)$", "", cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    # Try alias table again after cleaning
    if cleaned in _ALIASES:
        return _ALIASES[cleaned]

    return cleaned


# Eager load at import
reload_aliases()
