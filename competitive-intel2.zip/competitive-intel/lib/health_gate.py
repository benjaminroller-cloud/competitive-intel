"""Scrape health gating. Decides whether a snapshot is success / partial / failed
based on volume anomaly checks against the previous week's snapshot.

Used during the scrape step (raw failures) and again at the start of the diff
step (volume anomalies that the scraper couldn't catch)."""

from typing import Optional

VOLUME_ANOMALY_THRESHOLD = 0.20  # 20% week-over-week channel count change


def apply_volume_check(
    current_channel_count: int,
    previous_channel_count: Optional[int],
    current_health: str,
) -> str:
    """Downgrade a 'success' snapshot to 'partial' if the channel count moved
    more than VOLUME_ANOMALY_THRESHOLD vs last week.

    Already-failed or already-partial snapshots are left alone. The first scrape
    of a competitor (previous_channel_count is None) is left as-is — no baseline
    to check against."""
    if current_health != "success":
        return current_health
    if previous_channel_count is None or previous_channel_count == 0:
        return current_health

    delta = abs(current_channel_count - previous_channel_count) / previous_channel_count
    if delta > VOLUME_ANOMALY_THRESHOLD:
        return "partial"
    return current_health
