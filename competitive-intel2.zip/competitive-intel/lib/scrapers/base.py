"""The interface every competitor parser implements.

A parser takes raw HTML and returns a list of PackageSnapshot dicts. The scraper
orchestrator handles fetching the HTML, calling the right parser, and writing the
results to disk. Parsers do not touch disk and do not make HTTP requests."""

from dataclasses import dataclass, asdict
from typing import Protocol


@dataclass
class PackageSnapshot:
    """One observed package on one competitor at one point in time."""
    package_name: str          # as observed: "Plus", "Choice", "Orange"
    package_slug: str          # normalized: "plus", "choice", "orange"
    rack_price_cents: int      # standard non-promo price; -1 if not found
    channel_count: int         # as advertised; -1 if not found
    channel_list: list[str]    # raw channel names (normalization happens at diff time)
    promo_price_cents: int | None = None
    promo_duration_months: int | None = None
    promo_conditions: str | None = None

    def to_dict(self) -> dict:
        return asdict(self)


class Parser(Protocol):
    """All competitor parsers expose a single parse() function."""
    def parse(self, html: str) -> list[PackageSnapshot]:
        ...


def slugify(name: str) -> str:
    """Convert a display name into a stable slug for cross-week matching.
    Examples:
      'Plus' -> 'plus'
      'Sling Orange & Blue' -> 'orange_blue'
      'Sports + News' -> 'sports_news'
      'Hulu + Live TV' -> 'hulu_live_tv'"""
    s = name.lower().strip()
    # Strip the competitor brand prefix if present (e.g. 'Sling Orange' -> 'Orange')
    # Each parser can do its own brand-stripping before calling slugify.
    s = s.replace("&", "and").replace("+", "and")
    s = "".join(c if c.isalnum() or c.isspace() else " " for c in s)
    s = "_".join(s.split())
    return s
