"""Philo parser. Reference implementation — the other competitor parsers
follow this same structure.

Philo is the simplest target: one base plan, no zip-code gating, no
JavaScript-heavy rendering. If you're learning this codebase by reading
one file, read this one first."""

import re
from bs4 import BeautifulSoup
from lib.scrapers.base import PackageSnapshot, slugify


def parse(html: str) -> list[PackageSnapshot]:
    """Return the packages found on philo.com.

    Philo currently sells one base package (~$28/mo, 70+ channels) plus add-ons.
    Add-ons are out of scope per current config; we return only the base plan."""
    soup = BeautifulSoup(html, "html.parser")
    snapshots: list[PackageSnapshot] = []

    # Strategy: Philo's homepage advertises the price prominently and lists the
    # channel count. Both are likely to move across page redesigns, so we look
    # for them with several fallback selectors before giving up.
    price_cents = _extract_price_cents(soup)
    channel_count = _extract_channel_count(soup)
    channel_list = _extract_channel_list(soup)

    snapshots.append(PackageSnapshot(
        package_name="Philo",
        package_slug="base",
        rack_price_cents=price_cents,
        channel_count=channel_count,
        channel_list=channel_list,
    ))

    return snapshots


def _extract_price_cents(soup: BeautifulSoup) -> int:
    """Find the headline monthly price. Returns cents, or -1 if not found."""
    # Look for any $NN or $NN.NN pattern, then heuristically pick the smallest
    # plausible monthly price (Philo's promo and full prices both appear; we want
    # the rack rate, which is the higher one in the $20-$30 range).
    text = soup.get_text(" ", strip=True)
    candidates = re.findall(r"\$(\d{1,3}(?:\.\d{2})?)", text)
    plausible = []
    for c in candidates:
        try:
            val = float(c)
            if 15 <= val <= 50:  # Philo's price band
                plausible.append(val)
        except ValueError:
            pass
    if not plausible:
        return -1
    # Rack rate is the highest plausible price (promo is lower)
    return int(round(max(plausible) * 100))


def _extract_channel_count(soup: BeautifulSoup) -> int:
    """Find the advertised channel count. Returns -1 if not found."""
    text = soup.get_text(" ", strip=True)
    # Patterns like "70+ channels", "over 70 channels", "70 channels"
    m = re.search(r"(\d{2,3})\s*\+?\s*channels", text, flags=re.IGNORECASE)
    if m:
        return int(m.group(1))
    m = re.search(r"over\s+(\d{2,3})\s+channels", text, flags=re.IGNORECASE)
    if m:
        return int(m.group(1))
    return -1


def _extract_channel_list(soup: BeautifulSoup) -> list[str]:
    """Find the channel names listed on the page. May return [] if Philo's
    homepage doesn't list them (in which case we'd need a separate channels-page
    scrape — TODO if/when needed)."""
    # Philo lists channels in <img alt="..."> tags on its channel grid.
    channels = set()
    for img in soup.find_all("img"):
        alt = img.get("alt", "").strip()
        if alt and 2 <= len(alt) <= 40 and not alt.lower().startswith(("philo", "logo", "icon")):
            channels.add(alt)
    return sorted(channels)
