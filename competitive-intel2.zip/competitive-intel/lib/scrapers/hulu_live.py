"""hulu_live parser. SKELETON — not yet implemented.

To finish: implement parse() to return the packages observed on the live site.
Follow lib/scrapers/philo.py as the reference. Until this is done, scraping
hulu_live will produce a 'failed' snapshot."""

from lib.scrapers.base import PackageSnapshot


def parse(html: str) -> list[PackageSnapshot]:
    # TODO: implement once we look at the actual HTML together
    raise NotImplementedError("hulu_live parser not yet implemented")
