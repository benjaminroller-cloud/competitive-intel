"""fubo parser. SKELETON — not yet implemented.

To finish: implement parse() to return the packages observed on the live site.
Follow lib/scrapers/philo.py as the reference. Until this is done, scraping
fubo will produce a 'failed' snapshot."""

from lib.scrapers.base import PackageSnapshot


def parse(html: str) -> list[PackageSnapshot]:
    # TODO: implement once we look at the actual HTML together
    raise NotImplementedError("fubo parser not yet implemented")
